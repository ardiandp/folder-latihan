<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<!--
http://cariprogram.blogspot.com
nuramijaya@gmail.com
-->
<body>
<input type="text" name="input1" id="input1" />
<input type="submit" name="button" id="button" value="Popup" onclick="window.open('popup-pilih-checkbox-multiple-data.php', 'winpopup', 'toolbar=no,statusbar=no,menubar=no,resizable=yes,scrollbars=yes,width=300,height=400');" />
<br />
<input type="text" name="input2" id="input2" />
<br />
<label>
<input type="button" name="button2" id="button2" value="Ok" style="visibility:hidden;"  />
</label>
</body>
</html>
